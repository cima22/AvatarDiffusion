from distutils.core import setup

setup(
    # Application name:
    name="SDMige",

    # Version number (initial):
    version="0.1.0",

    # Application author details:
    author="Andrea De Lorenzo",
    author_email="andrea.delorenzo@units.it",

    # Packages
    packages=["sdmigeapi"],

    # Include additional files into the package
    include_package_data=True,

    # Details
    # url="",

    #
    # license="LICENSE.txt",
    description="Simple API for EESTEC Challenge",

    # long_description=open("README.txt").read(),

    # Dependent packages (distributions)
    install_requires=[
        "rpyc", "Pillow"
    ],
)