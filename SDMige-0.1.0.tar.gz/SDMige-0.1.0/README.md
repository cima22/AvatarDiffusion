# API for EESTEC Challange

## Build and distibute
`python setup.py sdist`