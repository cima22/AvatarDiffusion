from typing import List
import rpyc
from PIL import Image
from io import BytesIO


def generate_images(prompt: str, negative: str = "", n_imgs: int = 1) -> List:
    sd = rpyc.connect("140.105.164.232", 18862, config={"sync_request_timeout": 120})
    outputs: List[bytes] = sd.root.exposed_generate(prompt, negative, n_imgs)
    ret: List = []
    for o in outputs:
        image = Image.open(BytesIO(o))
        ret.append(image)
    return ret


def generate_text(prompt: str, max_length=50) -> str:
    llm = rpyc.connect("140.105.140.237", 18862, config={"sync_request_timeout": 120})
    text: str = llm.root.exposed_generate(prompt,max_length)
    return text


if __name__ == "__main__":
    print(generate_text("Write the lyrics of a song.", 100))